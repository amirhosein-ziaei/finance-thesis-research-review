# Phase 3 go / no-go

Date: 9 October 2026. Benchmark: the feasibility gates in `Final thesis adjudication October
2026.md` (section *Fifteen working-day pilot*). Everything here is **measurement feasibility**.
No result identifies a causal effect.

## Decision

**GO for a narrowed thesis: adviser fee-recovery accounting and shareholder incidence, with
ledger reconstruction.**

**NO-GO for the original expiry-timing question as the primary contribution.** Keep it only as
a bounded, descriptive secondary analysis, restricted to remaining-balance disclosure formats.

**The 20-fund / 8-adviser pilot is justified only in this narrowed form**, and only after the
two preparatory steps in §4.

## 1. Gates from the adjudication report

| Gate (adjudication report) | Phase 3 evidence | Verdict |
| - | - | - |
| **Kill project** if actual recoveries cannot be separated from eligible balances | Separate expense lines at both recovering advisers ("Recoupment Fees", "Fees recaptured by the Advisor"); balances in separate schedules. Zero recoveries are provable by arithmetic | **Pass** |
| **Kill project** if access cannot be made reliable | EDGAR works with a declared contact User-Agent; 16 primary financial reports now read (plus 13 locator pages); adviser sites are not archives | **Pass here**; the student's own network is untested |
| **Kill project** if expansion would consume most of the horizon | Towpath's five-year history needed 7 reports; manual reading plus arithmetic checks per report | **Pass, provisionally**: needs measured human time per history |
| Continue: ≥80% of sampled histories with interpretable period-level recovery and cap information | 6 of 6 funds (annual level) | **Pass** on a tiny, selected sample |
| Continue: ≥10 histories with reconciled eligible-claim transitions | Strict: 7 intervals close; 3 more close exactly to a lapsed vintage; 0 with every component disclosed. Funds with ≥1 strictly closing interval: 3 (Towpath Technology, Counterpoint Tactical Equity, Al Frank), plus a trivial 0→0 year for Towpath Focus | **Not met** (sample too small; partly by design) |
| Continue: credible path to multiple independent advisers | 4 independent advisers verified. Actual recoveries at only 2 | **Partial** |
| Deadline component: recoveries allocated to vintages or narrow bounds | Allocation identified in 2 Counterpoint intervals only. Impossible for original-amount formats (Towpath Focus) | **Weak** |
| **Kill deadline component** if allocation unknowable, if reporting conventions mechanically generate near-expiry observations, or if waiver age cannot be separated from expiry | Allocation unknowable in 1 of 2 recovering funds. Recovery is governed by cap headroom, which moves with fund growth. Every vintage lapses after a fixed 3-year (or fiscal-year-based) window, so age equals time-to-expiry | **Triggered in part**: demote the timing question |

## 2. Measurement feasibility A–G

| | Question | Answer | Status |
| - | - | - | - |
| A | Actual recoupment measurable? | **Yes, from annual reports**: explicit lines, or 0 by statement arithmetic. Semiannual figures can be missing from the statement (Towpath, May 2023) or reversed by year end (May 2024) | partially verified |
| B | Rights trackable across periods? | **Yes for remaining-balance formats** (Counterpoint, Western Asset, Al Frank; Towpath Technology because it never recovers). **No for Towpath Focus**, whose schedules list original amounts | partially verified |
| C | Expiry vs forgiveness distinguishable? | **Sometimes.** Stated expiry: Al Frank (2 years). Stated forgiveness: Towpath Focus FY2024 ($24,574). Five other lapses are exact in amount but undisclosed in kind | partially verified / inferred |
| D | Recoveries allocable to vintages? | **Only when one vintage moves or all go to zero**: Counterpoint FY2024 (all of the $118,758 from the vintage due 30 Sep 2024) and the six months to Mar 2025 (both vintages exhausted). Never under original-amount schedules. No FIFO used | partially verified (2 cases) |
| E | Cap headroom measurable? | **Approximately**: annual gross ratio vs cap, ±0.01%. The daily, class-level contractual test is not observable | inferred precision |
| F | Shareholder burden in $ and bps? | **Yes.** $ from annual lines; bps via advisory fee ÷ rate, which agrees with ratio gaps within about 1 bp. Towpath Focus FY2023 ≈ 9.0 bps; Counterpoint Tactical Equity FY2024 ≈ 10.9 bps, FY2025 ≈ 1.8 bps; forgiveness saved Towpath Focus holders ≈ 7 bps in FY2024 | derived approximation |
| G | Near-expiry pattern separable from age, caps and operating costs? | **No, not with this design.** Recoveries occur when gross expenses fall below the cap, usually as assets grow. Every vintage's time-to-expiry is mechanically its age. Observed final-year recoveries (Counterpoint FY2024; Towpath Focus FY2023, apparently) coincide with headroom, and Counterpoint also recaptured a vintage with about 18 months left. A descriptive pattern can be shown; a deadline effect cannot be identified | — |

## 3. Answers on the thesis question

- **Retain the expiry-timing question?** Not as the primary question. The data can describe
  *what happened to each vintage* (recovered, forgiven, lapsed) in remaining-balance formats.
  They cannot separate a deadline incentive from headroom, age and growth.
- **Narrow toward accounting incidence?** **Yes.** The defensible core is to measure how often
  and how much advisers recover, what shareholders pay in bps, how often rights lapse or are
  forgiven, and how disclosure formats affect what can be known. That is descriptive and
  institutional, and it is a viable master's thesis. It also partly answers the original
  question's second half ("how much of the burden is borne by shareholders").
- **Stop?** No. No kill condition for the whole project is triggered.

## 4. Smallest defensible next step (about 1 week)

1. **Human second coding of the existing six histories**: about 30 key figures (recoveries,
   balances, expiries, forgiveness) re-read from the PDF/HTML by you or a colleague. Turns
   *partially verified* into *verified* and measures human minutes per report.
2. **Build a documented sampling frame before choosing 20 funds**: for example, SEC full-text
   search of 2024–2025 N-CSR filings for recapture/recoupment language, recording for each hit
   the adviser, administrator template and schedule basis. Draw funds from the frame,
   stratified by adviser, so that prevalence and format shares are estimable.
3. **Re-adjudicate the narrowed contribution** with your supervisor before the 20-fund pilot.

After these, a 20-fund / 8-adviser *incidence* pilot is justified. Its gates:
- interpretable annual recovery for ≥80% of sampled funds;
- remaining-balance format share reported;
- ≥10 strictly closing intervals;
- measured coding time per history.
