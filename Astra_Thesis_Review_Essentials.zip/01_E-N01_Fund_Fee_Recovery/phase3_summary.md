# Phase 3 summary

Date: 9 October 2026. Phase 3 resolved the access problem, closed the Towpath and Counterpoint
gaps where documents allowed, validated two further independent advisers, and separated strict
from assumption-dependent accounting. **Measurement feasibility only, no causal claims.**

## What changed since Phase 2

| | Phase 2 | Phase 3 |
| - | - | - |
| SEC access | Blocked (no declared contact) | Working: declared research User-Agent with the owner's authorised contact, kept in an untracked scratchpad file and never written to the repository |
| Primary financial reports read | 5 | **16** (+ Towpath FY2021, FY2022, FY2025 and May 2023/2024/2025 semiannuals; Counterpoint FY2023; Al Frank FY2024, FY2025; Western Asset Oct 2025, Apr 2026) |
| Independent advisers verified | 2 | **4** (Oelschlager; Counterpoint; Kovitz / Focus Financial; Franklin Templeton Fund Adviser) |
| Funds | 4 | **6** (Western Asset tracked by class A/C/I) |
| Source observations | 162 | **291** (single coder, partially verified) |
| Dash handling | 16 cells left unresolved | 29 dash or absent-line cases classified: 27 zero by statement arithmetic, 2 context-only |
| Ledger views | 1 audit with a mixed conditional column | Separate **strict** and **conditional** ledgers |

## Retrieval (all logged in `data/manifests/access_log.csv`; hashes in the manifest)

Retrieved:
- Towpath FY2022 N-CSR (0001162044-23-000151), FY2025 N-CSR, FY2021 N-CSR;
- Towpath N-CSRS for May 2023, May 2024 and May 2025;
- Counterpoint FY2023 N-CSR;
- Al Frank FY2024 and FY2025 N-CSRs;
- Western Asset Oregon N-CSRS (Oct 2025);
- 9 EDGAR filing indexes and 2 full-text-search results, used only as locators.

Identity checks used each filing's cover/registrant, period headings, XBRL `dei` facts and
fund names. Excluded: an N-CSR/A that turned out to amend a different series (Parvin), not
Towpath. No retrieval failed in Phase 3.

## Key findings

1. **Towpath $25,702: not reconcilable.** The vintage due 30 Nov 2023 is listed at $57,574 in
   every schedule from FY2021. There was no recoupment before FY2023 (arithmetic), and
   $25,501 in FY2023. So $57,574 − $25,501 − $25,702 leaves **$6,371** unexplained even in
   the most favourable allocation. The note is most likely misstated. Strict status:
   unresolved.
2. **Towpath schedules list original amounts.** The listed amounts are unchanged after
   $14,364 and $20,583 of half-year recoveries. Towpath Focus's remaining balances, and the
   vintage source of its recoveries, are therefore not disclosed.
3. **A half-year recoupment ($20,583) was reversed by year end**, when the adviser forgave
   recovery for FY2024. Only annual figures measure incidence.
4. **Towpath Technology $53,123: explained in amount, not in kind.** The vintage vanishes at
   its 30 Nov 2024 expiry date with recoupment 0 by arithmetic. The same pattern repeats for
   $45,800 at 30 Nov 2025. Expiry is the natural reading; it is never stated.
5. **Counterpoint Tactical Equity: complete from 30 Sep 2023.**
   - $196,900 eligible at 30 Sep 2023, by expiry: $131,492 (2024), $42,239 (2025), $23,169 (2026).
   - FY2024: recaptured $118,758, all from the vintage due 30 Sep 2024, because the other two
     vintages are unchanged. **$12,734 lapsed undisclosed.**
   - Six months to Mar 2025: recaptured the remaining $65,408. Closing stated zero.
   - Missing: the opening balance at 30 Sep 2022 (FY2022 report), and the kind of the $12,734
     lapse.
6. **Al Frank states expiries explicitly** ($146,546; $129,083), and its FY2025 ledger closes to
   the dollar. It never recovers, because gross expenses (1.47–1.48%) exceed its 1.24% cap.
7. **Western Asset** reports remaining balances by class and expiry, with recapture stated
   as zero. The class rows reproduce fund-level waivers exactly ($86,513; $78,353).

## Strict vs conditional (27 fund- or class-intervals)

| Strict status | Count | Intervals |
| - | - | - |
| `reconciled` (every component disclosed or proven) | **0** | — |
| `reconciled_undisclosed_flows_net_zero` | **7** | Towpath Technology FY2021–FY2023; Counterpoint Tactical Equity six months to Mar 2025 and FY2025; Al Frank FY2025; Towpath Focus FY2025 (0→0) |
| `implied_undisclosed_reduction` (exact amount, kind undisclosed) | **3** | Technology FY2024 ($53,123), FY2025 ($45,800); Tactical Equity FY2024 ($12,734). Each equals a vintage reaching its expiry date |
| `incomplete` | **17** | All other Towpath Focus intervals (original-amount schedule); Tactical Income (context-only dashes); first intervals lacking an opening balance; Western Asset classes (no class-level waivers, opening not retrieved) |

**Conditional view (C0: undisclosed flows and context dashes = 0; Focus listed sums treated as
remaining):** 12 intervals reconcile and 4 show residuals. The 3 lapses reconcile under C3
(lapse = expiry). Focus FY2023 reconciles only under C2, which replaces the disclosed $25,702
with $32,073; at face value (C1) it misses by −$6,371. **Five intervals reconcile only
conditionally**: Towpath Focus FY2022 and FY2024, and Tactical Income FY2024, the six months
to Mar 2025 and FY2025.

## Outputs

`strict_accounting_ledger.csv`, `conditional_accounting_ledger.csv`, `vintage_ledger.csv`,
`longitudinal_ledger.csv`, `accounting_audit.csv` (Phase 2 diagnostic, now share-class and
schedule-basis aware), `third_adviser_validation.md`, `remaining_measurement_problems.md`,
`phase3_go_no_go.md`. New data: `data/processed/zero_derivations.csv`, `schedule_basis.csv`,
`conditional_assumptions.csv`. Tests: 65 passing.
