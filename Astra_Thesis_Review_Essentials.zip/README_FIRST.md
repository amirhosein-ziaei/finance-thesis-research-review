# Astra Thesis Research Review - source package

This ZIP contains the six essential source documents recommended for an independent comparison of two thesis candidates: E-N01 (fund fee recovery) and G-P2 (reemployment beliefs and debt distress).

## What is included

- 00_Original_Adjudication/Final thesis adjudication October 2026.md
- 01_E-N01_Fund_Fee_Recovery/phase3_summary.md
- 01_E-N01_Fund_Fee_Recovery/phase3_go_no_go.md
- 02_G-P2_Reemployment_Debt/preliminary_regressions.md
- 02_G-P2_Reemployment_Debt/prediction_comparison.md
- 02_G-P2_Reemployment_Debt/phase2_feasibility_decision.md

## Additional recommended documents NOT included

These five optional files are not present in the accessible source uploads. Do not treat them as included or reconstructed. Obtain the originals from the existing GitHub PR branches if Astra needs a deeper audit:

- 01_E-N01_Fund_Fee_Recovery/remaining_measurement_problems.md -- Not uploaded here; original E-N01 repo currently inaccessible
- 01_E-N01_Fund_Fee_Recovery/strict_accounting_ledger.csv -- Not uploaded here; original E-N01 repo currently inaccessible
- 01_E-N01_Fund_Fee_Recovery/conditional_accounting_ledger.csv -- Not uploaded here; original E-N01 repo currently inaccessible
- 02_G-P2_Reemployment_Debt/model_specification.md -- Public GitHub source: https://github.com/amirhosein-ziaei/reemployment-beliefs-debt-thesis/blob/claude/trusting-allen-6o7x90/outputs/model_specification.md
- 02_G-P2_Reemployment_Debt/measurement_sensitivity.md -- Public GitHub source: https://github.com/amirhosein-ziaei/reemployment-beliefs-debt-thesis/blob/claude/trusting-allen-6o7x90/outputs/measurement_sensitivity.md

The original E-N01 project was reported at: https://github.com/amirhosein-ziaei/fund-fee-recoupment-thesis/pull/1 (not publicly accessible in this environment).

The G-P2 project branch is public: https://github.com/amirhosein-ziaei/reemployment-beliefs-debt-thesis/pull/1

This package is for document-grounded independent critical review, not raw-data/code reproducibility. Findings in Claude reports should not be treated as independently validated. No raw individual-level SCE records are included.
